from fastapi import FastAPI
from routers import store

app = FastAPI(
    title="VASL ALAP Store API",
    version="1.0.0",
    description="Stores LLM inference results into the VASL ALAP database"
)

app.include_router(store.router)


@app.get("/health")
async def health():
    return {"status": "ok"}
