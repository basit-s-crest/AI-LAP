from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


# ── Nested input models ──────────────────────────────────────────────────────

class SignalIn(BaseModel):
    signal_code:  str
    signal_label: Optional[str] = None
    confidence:   float = Field(ge=0.0, le=1.0)
    dimension:    Optional[str] = None   # hopelessness | isolation | self_harm | crisis | cultural


class ShapIn(BaseModel):
    span:        str               # max 5 words per spec
    weight:      float
    signal_code: Optional[str] = None
    rank:        Optional[int] = None


# ── Main inference result payload ────────────────────────────────────────────

class InferenceResultIn(BaseModel):
    """
    Payload sent to POST /v1/store-result after the LLM generates a response.
    Maps 1-to-1 with inference_events + child tables.
    """
    event_id:           str                        # evt_01HX... from source system
    member_token:       str                        # pseudonymized, e.g. mbr_a3f9c2d8e1
    org_id:             str
    source_type:        str                        # peer-post | journal | chat | assessment
    event_timestamp:    datetime                   # when the original text was created
    model_version:      Optional[str] = None

    # Risk output
    risk_tier:          str                        # low | moderate | high | crisis
    risk_score:         float = Field(ge=0.0, le=1.0)
    risk_trend:         Optional[str] = None       # stable | increasing | decreasing

    cultural_context:   List[str] = []             # ["AAVE_CODE_SWITCH", "MINIMIZATION"]
    recommended_action: Optional[str] = None
    review_deadline:    Optional[datetime] = None

    # Child rows
    active_signals:     List[SignalIn] = []
    shap_attributions:  List[ShapIn]   = []


class InferenceResultOut(BaseModel):
    status:   str
    event_id: str
    db_id:    int


# ── Review action payload ────────────────────────────────────────────────────

class ReviewIn(BaseModel):
    """
    Payload sent to POST /v1/review/action when a clinician submits a review.
    """
    review_id:       str                           # rev_01HX... from source system
    event_id:        str                           # event_id string (evt_01HX...)
    member_token:    str
    therapist_id:    str
    action:          str
    # contacted_member | scheduled_session | escalated_to_crisis
    # no_action_required | flagged_false_positive
    clinician_notes: Optional[str] = None
    reviewed_at:     datetime


class ReviewOut(BaseModel):
    status:    str
    review_id: str
